<!--
 * @Author: Wuyao 1955416359@qq.com
 * @Date: 2023-04-28 13:53:57
 * @LastEditors: Wuyao 1955416359@qq.com
 * @LastEditTime: 2023-10-15 15:21:51
 * @FilePath: \UnetV2\readme.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->

src\make_dataset.py 划分数据集  
使用make_dataset.py可以将已经打完标签的数据集按照7：2：1的比例划分为训练集、验证集、测试集  
在\image目录下生成三个新的文件夹，分别存储训练集、验证集、测试集的图片  
在\label目录下生成三个新的文件夹，分别存储训练集、验证集、测试集的标签  
训练模型的时候要保证训练集的图片和标签的文件夹在一个目录下面，并且名字为JPEGImages和JPEGImages  
    例如：E:\Code\wyUnet\data\JPEGImages  E:\Code\wyUnet\data\SegmentationClass  
    在train.py的如下代码中进行修改  
    data_path = 'E:/Code/wyUnet/data'      



src\train.py  ：训练  
src\test.py ： 测试  
src\test_ValDataset.py  ：使用测试test集数据跑模型
originalDataset  ：存储原始数据集及其标签
newDataset： 使用src\make_dataset.py 划分数据集后会在该目录下生成验证集和测试集
trainDataset： 使用src\make_dataset.py 划分数据集后会在该目录下训练集


## wyunetv2.1  
    优化了车道线计算角度的逻辑
    网络参数更改，可转换为TensorRT格式文件

## wyunetv2.2  
    修复已知BUG
    优化训练过程，增加训练可视化，无需指定权重保存路径，训练结果会保存在params/exp文件夹中

## wyunetv2.3  
    1.优化代码，模型会将损失值作为指标，模型训练结束之后会保存最后一次训练结束的模型和所有模型中损失值最小的模型
    2.训练结果会保存在params/exp文件夹中 
    3.epx文件夹中包括损失函数曲线图、每一轮损失值的excel表格、训练过程的对比图在params\exp\train_result 
    4.对比图左侧是标签，右侧是训练结果
    5.增加tools.py 提高代码规范性
    6.src\test_ValDataset.py 优化代码 只检测到单条线的时候会按照上次检测的结果去做曲线拟合
    6.1 nwindows: 窗门的数量。该参数决定了在图像中使用多少个窗口来搜索车道线。可以根据道路的宽度和车道线的曲率来调整该参数。如果道路比较宽或者车道线比较弯曲，可能需要增加窗口的数量
    6.2 margin: 窗口的宽度。该参数决定了窗口在x轴上的宽度，用于确定左右车道线的搜索范围。可以根据车道线的宽度来调整该参数。如果车道线较宽，可能需要增加窗口的宽度
    6.4 minpix: 每个窗口至少需要的像素点数量，该参数决定了窗口内的像素点数目，用于判断该窗口内是否存在车道线。可以根据图像的分辨率和车道线的清晰度来调整该参数。如果图像分辨率较高或者车道线较清晰，可能需要增加该参数的值。
    6.4 minLane: 最小的车道线宽度。该参数用于确定车道线的最小宽度，用于过滤掉宽度较小的噪声。可以根据道路的宽度来调整该参数。如果道路较窄，可能需要减小该参数的值
    6.5 增加窗口的数量和宽度可以提高车道线检测的准确性，因为更多的窗口和更宽的窗口可以覆盖更大的搜索范围，减小了漏检和误检的概率。同时，增加每个窗口至少需要的像素点数量和最小车道线宽度可以过滤掉较小的噪声，提升车道线检测的稳定性

# wyunet-v3  
    wyunet网络优化  
    1.在原来网络的基础上编码器和解码器部分使用深度可分离卷积。
    深度可分离卷积通过先进行深度卷积，再进行逐点卷积，从而减少参数量和计算量。
    2.在编码器部分，输入经过一次传统卷积操作后，再使用深度可分离卷积。
    3.在解码器部分，先进行上采样操作，然后将上采样结果与编码器部分的输出进行拼接，再使用深度可分离卷积。  
    4.在initialize_weights方法,使用了init.xavier_uniform_对卷积层的权重进行Xavier均匀初始化, 并使用init.normal_对逐点卷积的权重进行正态分布初始化。同时,对BatchNorm层的权重也进行了初始化。可以根据需要调整mean和std参数来设置不同的均值和标准差。  

## wyunet-v3.2  2023-10-15 15:12:28
    1.取消v3网络中深度可分离卷积部分，采用分离卷积虽然可以减少参数量，但转为ONNX模型之后精度会下降。也可能是训练集样本不够导致。v3网络使用src\train_SeparableUNet.py训练，扩大数据集之后重新实验  
    2.支持多种unet网络结构，差异详见源码。使用不同网络结构进行训练，详见样例                    
        src\train_egeunet.py  src\train_SeparableUNet.py  src\train_unetv3_2.py  
    3.弃用src\testv3_ValDataset.py  
    4.优化src\export_unet2onnx.py  
        支持unet模型转换，使用时需导入对应网络结构和训练好的参数，如下所示
        from Unetv3_2 import *
        weights='params\exp5\min_loss.pt'   
        net=UNet(out_channels = num_classes)   #import wyUnet
    5.优化推理算法，详见src\inferonnx.py
        需要将训练好的模型转为ONNX格式，进行推理。请自行安装ONNX-GPU部署，在训练结束后，只使用了CPU来验证模型的可行性  
    6.请参照src\inferonnx.py在EPAI-car中重新部署，以及与ROS的通信  
    7.若速度无法满足要求，可使用onnx模型在嵌入式平台上使用C++语言和onnxruntime-gpu库对模型进行加速推理。对处理结果处理即拟合二阶曲线该部分算法需要移植到C++，后续会更新
    8.训练使用src\train_unetv3_2.py  
    



##### 以下思路可提供参考 2023-07-22 15:02:48更新

    1. 由于git库的删除，v2.1中的提及到的功能无法实现，通过历史找回了wyunet在fp16精度下的trt模型，以及测试脚本src\test_tensorrt.py 通过测试发现在加速之后帧率在3060Ti G6X上面能够跑到500帧/秒，但精度严重缺失，应该是在转换过程中出现了问题，未来可以在此基础上进一步研究。需要注意的是该版本训练生成的模型无法转为trt模型，需要对src\train.py进行更改，将整个网络结构及其参数进行保存，该功能和模型转换部分的代码已经丢失。理论上来说，v2.1的train.py训练之后保存的模型，对其重新构建推理器，使其不再调用src\Unet.py，在嵌入式平台的推理应该会有加快。
    2. model.onnx为wyunet的onnx格式模型，该模型同样存在精度严重缺失，应该是在转换过程中出现了问题，未来可以在此基础上进一步研究。思路为使用onnx模型在嵌入式平台上使用C++语言和onnxruntime-gpu库对模型进行加速推理。相关代码为src\export_unet.py src\detect_onnx.py 
    3. src\demo.py  将卷积函数进行量化，减少计算量实现模型的快速推理，该功能未能实现
    4. 针对比赛时的车道线检测，只要求了车道线，没有对车道线的类别进行要求，目前的推理器将所有非背景的标签统一进行二值化了，对于模型来说可以理解为一种标签，所以可以尝试制作数据集时减少标签的类别，理论上模型减少了输出参数，是可以在推理时实现一定的加速的，当输出通道数较大时，会生成更多的特征图，导致计算量增加。同时，理论上来说，v2.1的train.py训练之后保存的模型，对其重新构建推理器，使其不再调用src\Unet.py，在嵌入式平台的推理应该会有加快。二者结合一下
    5. 对整个网络进行重构，使用libtorch-win-shared-with-deps-2.0.1+cu118.zip 提供的C++接口，将全部代码使用C++进行重构，并部署到嵌入式平台