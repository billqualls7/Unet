
# '''
# Author: Wuyao 1955416359@qq.com
# Date: 2023-06-27 14:33:44
# LastEditors: Wuyao 1955416359@qq.com
# LastEditTime: 2023-10-14 21:56:43
# FilePath: \UnetV2\src\export_unet.py
# Description: 将模型导出为onnx模型
# '''

import os
import torch
import torchvision
import torch.onnx as onnx
import tools
from Unetv3_2 import *
from egeunet import *

save_dir = 'run/onnx' 
num_classes = 6
onnx_path = "model.onnx"
#------------------------------------------------------------------
weights='params\exp5\min_loss.pt'  
net=UNet(out_channels = num_classes)   #import wyUnet
#------------------------------------------------------------------
device = torch.device("cuda") 
save_path = tools.mkdirr(save_dir)
save_path_out = os.path.join(save_path,onnx_path)

# model = UNet(out_channels = num_classes).to(device)
# checkpoint = torch.load(weights)
# # print(checkpoint)
# model.load_state_dict(checkpoint.state_dict())
# # net=UNet(out_channels = num_classes)   #import wyUnet
# # net.load_state_dict(torch.load('params\demo\exp5\min_loss.pt'))
# model.eval()  # 设置为推理模式


net.load_state_dict(torch.load(weights).state_dict())
net.eval()

# 创建一个虚拟输入
input_shape = torch.randn(1, 3, 256, 256)


output_names = ["output"]  # 输出节点的名称，可以根据实际情况修改
# 将PyTorch模型转换为ONNX格式

torch.onnx.export(
    net,
    input_shape,
    save_path_out,
    verbose=False,
    input_names=["input"],  # 输入节点的名称，可以根据实际情况修改
    output_names=output_names,
    opset_version=11  # 可选的 ONNX 版本号，根据需要指定
)
