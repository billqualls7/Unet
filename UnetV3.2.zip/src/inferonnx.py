# -*- coding: utf-8 -*-
# '''
# Author: Wuyao 1955416359@qq.com
# Date: 2023-10-08 16:05:57
# LastEditors: Wuyao 1955416359@qq.com
# LastEditTime: 2023-10-08 16:06:29
# FilePath: \paddle\inferonnx.py
# Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
# '''

import onnxruntime as ort
import numpy as np
import cv2
import matplotlib.pyplot as plt
from PIL import Image
import time
from tools import *





if __name__ == '__main__':
    previous_left_fit = [0, 0, 0]
    previous_right_fit = [0, 0, 0]
    image_path = 'demo/001230.png'
    model_path = 'run\onnx\exp22\model.onnx'
    input_size = (256, 256)
    session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])  #需改成GPU

    
    input_data = load_image_as_array(image_path, input_size)
    input_data = input_data.astype(np.float32)

    time1 = time.time()
    output = session.run(None, {'input': input_data})[0]

    # print(output.shape) 
    output_array = output[0]
    output_array = np.transpose(output_array, (1, 2, 0))

    predicted_labels = np.argmax(output_array, axis=2)

    # 将类别映射为灰度值(0-255)
    gray_image = predicted_labels.astype(np.uint8) * 255
   
    vtherror=get_angle(gray_image)

    time2 = time.time() 
    # plt.imshow(gray_image, cmap='gray')
    # plt.show()
    
    print("vtherror:",vtherror)
    print(time2-time1)
    print("fps:",1/(time2-time1))

